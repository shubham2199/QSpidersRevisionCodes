package com.login;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class LoginValidate {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jayesh");
		EntityManager em=emf.createEntityManager();
		
		System.out.println("Enter the email");
		String email=sc.next();
		System.out.println("Enter the password");
		String password=sc.next();
		
		Query q=em.createQuery("select user from User user where user.email=?1 and user.password=?2");
		q.setParameter(1, email);
		q.setParameter(2,password);
		
		List<User> user=q.getResultList();
		if(user.size()>0) {
			System.out.println("Welcome");
		}
		else 
			System.out.println("Enter valid details");
		
		sc.close();
	}

}
