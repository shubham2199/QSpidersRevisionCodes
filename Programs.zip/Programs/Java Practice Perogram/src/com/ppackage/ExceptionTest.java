package com.ppackage;

public class ExceptionTest {

	public static void main(String[] args) {
		
		try{
			throw new Exception("A");
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}finally {
			System.out.println("B");
		}
	}

}



/*
 * O/P
 * A
 * B
 * 
 */