package com.ppackage;

public class OverridingTest {

	public static void main(String[] args) {
		
		Parent p = new Child();
		p.print();
		
//		Child c1 = (Child) new Parent();
//		c1.print();          // Throws an error because we can't type cast child to parent.
		
		Parent p1 = new Parent();
		p1.print();
		
		Child c = new Child();
		c.print();
	}

}

class Parent{
	void print() {
		System.out.println("Parent");
	}
}

class Child extends Parent{
	void print() {
		System.out.println("Child");
	}
}




/*
O/P

Child
Parent
Child
*/