package com.ppackage;

public class ComplexIncrementProgram {

	public static void main(String[] args) {
		int x = 5;
		int x1 = x++ + ++x;
		System.out.println(x1);
	}

}


/*
 O/P
 
  12
 */
