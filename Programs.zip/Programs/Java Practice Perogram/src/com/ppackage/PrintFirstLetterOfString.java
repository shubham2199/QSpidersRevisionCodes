package com.ppackage;

public class PrintFirstLetterOfString {

	public static void main(String[] args) {
		String str = "I LOVE MY WORLD MY LIFE MY FAMILY MEMBERs.";
		
		//split function to make an array of each word in the string split by space.
		String[] str2 = str.split(" ");
		for(int i=0;i<str2.length;i++) {
			System.out.print(str2[i].charAt(0)+" ");
		}

	}

}


/*
 O/P
 
 I L M W M L M F M 
 
 */