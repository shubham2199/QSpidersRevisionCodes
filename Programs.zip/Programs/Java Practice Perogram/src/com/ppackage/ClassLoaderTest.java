package com.ppackage;

public class ClassLoaderTest {

	public static void main(String[] args) {

		System.out.println(String.class.getClassLoader());
		System.out.println(ClassLoaderTest.class.getClassLoader());
	}

}


/*O/P
 * 
 * null
	jdk.internal.loader.ClassLoaders$AppClassLoader@c387f44
 */