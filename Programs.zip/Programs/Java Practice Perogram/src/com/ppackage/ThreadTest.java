package com.ppackage;

public class ThreadTest extends Thread {

	public void run() {
		System.out.println("A");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadTest t = new ThreadTest();
		t.start();
		System.out.println("B");
		t.run();
		System.out.println("C");
	}

}

/*O/P
 * B A C A
 * 
 */
