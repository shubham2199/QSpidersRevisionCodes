package com.ppackage;

public class Outer {
	
	private int x =10;
	
	class Inner{
		private int x = 20;
		
		public void print() {
			System.out.println(x);
		}
	}

	public static void main(String[] args) {
		Outer outer = new Outer();
		Outer.Inner inner = outer.new Inner();
		inner.print();
	}

}


/*
 * O/P
 * 20
 */