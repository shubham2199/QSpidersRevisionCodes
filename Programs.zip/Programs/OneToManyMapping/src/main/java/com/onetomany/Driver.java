package com.onetomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Driver {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jayesh");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		Hospital hospital=new Hospital();
		hospital.setId(1);
		hospital.setName("Apollo");
		
		Branch b=new Branch();
		b.setId(1);
		b.setName("Pune");
		b.setPincode(411052);
		
		Branch b1=new Branch();
		b1.setId(2);
		b1.setName("Mumbai");
		b1.setPincode(400000);
		
		Branch b2=new Branch();
		b2.setId(3);
		b2.setName("Delhi");
		b2.setPincode(200000);
		
		List<Branch>branches=new ArrayList<Branch>();
		branches.add(b);
		branches.add(b1);
		branches.add(b2);
		
		hospital.setBranches(branches);
		
		et.begin();
		em.persist(b);
		em.persist(b1);
		em.persist(b2);
		et.commit();
	}

}
