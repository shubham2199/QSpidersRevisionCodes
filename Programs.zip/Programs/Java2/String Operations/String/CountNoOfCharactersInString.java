import java.util.Scanner;
public class CountNoOfCharactersInString {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the String");
        String s1=s.nextLine();
        s1=s1.toLowerCase();
        System.out.println("After Converting the String to lower case : "+s1);
        int vcount=0;
        int ccount=0;
        int scount=0;
        int sccount=0;
        int ncount=0;
        for(int i=0;i<=s1.length()-1;i++){
            if(s1.charAt(i)=='a'||s1.charAt(i)=='e'||s1.charAt(i)=='i'||s1.charAt(i)=='o'||s1.charAt(i)=='u'){
                vcount++;
            }
            else if(s1.charAt(i)==' '){
                scount++;
            }
            else if(s1.charAt(i)=='!'||s1.charAt(i)=='@'||s1.charAt(i)=='#'||s1.charAt(i)=='$'||s1.charAt(i)=='%'||s1.charAt(i)=='&'||s1.charAt(i)=='*'||s1.charAt(i)=='.'||s1.charAt(i)==','){
                sccount++;
            }
            else if(s1.charAt(i)=='0'||s1.charAt(i)=='1'||s1.charAt(i)=='2'||s1.charAt(i)=='3'||s1.charAt(i)=='4'||s1.charAt(i)=='5'||s1.charAt(i)=='6'||s1.charAt(i)=='7'||s1.charAt(i)=='8'||s1.charAt(i)=='9'){
                ncount++;
            }
            else 
            ccount++;
        }
        System.out.println("count of Vovels is: "+vcount);
        System.out.println("Count of Consonants is: "+ccount);
        System.out.println("Count of spaces is: "+scount);
        System.out.println("Count of Special Characters is: "+sccount);
        System.out.println("Count of Numbers is: "+ncount);
    }
}
