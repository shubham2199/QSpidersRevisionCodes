import java.util.Scanner;
public class ReverseEachWord {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the String");
        String s1=s.nextLine();
        String[] s2=s1.split(" ");
        String rev="";
        for(int i=0;i<s2.length;i++){
            String s3=s2[i];
            String rev2="";
            for(int j=s3.length()-1;j>=0;j--){
                rev2=rev2+s3.charAt(j);
            }
        rev=rev2+" "+rev; 
        }
        System.out.println(rev);
        s.close();
    }
}