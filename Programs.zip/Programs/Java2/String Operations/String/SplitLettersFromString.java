import java.util.Scanner;
public class SplitLettersFromString {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the String");
        String s1=s.nextLine();
        String[] s2=s1.split(" ");
        System.out.println(s2);
        for(int i=0;i<s1.length();i++){
            String s3=s2[i];
            System.out.println(s3);
        }
    }
}
