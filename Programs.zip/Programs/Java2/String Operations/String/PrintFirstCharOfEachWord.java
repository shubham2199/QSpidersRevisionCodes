import java.util.Scanner;

class PrintFirstCharOfEachWord{
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String s1=s.nextLine();
        String[] s2=s1.toCharArray();
        
    }
}