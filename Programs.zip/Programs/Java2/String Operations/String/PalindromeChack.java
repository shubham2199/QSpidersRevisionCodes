import java.util.*;
public class PalindromeChack {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.print("Enter the String value : ");
        String s1=s.nextLine();
        String s2="";
        int l=s1.length();
        for(int i=l-1;i>=0;i--){
            s2=s2+s1.charAt(i);
        }
        if(s1.equals(s2)){
            System.out.println("The Entered string is Palindrome");
        }
        else
        System.out.println("The Entered string is not Palindrome");
    }
}
