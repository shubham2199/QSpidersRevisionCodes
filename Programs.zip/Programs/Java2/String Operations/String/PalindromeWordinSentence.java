import java.util.Scanner;

public class PalindromeWordinSentence {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        String s1=s.nextLine();
        String[] s2=s1.split(" ");
        for(int i=s2.length-1;i>=0;i++){
            isReverse(s2[i]);
        }
    }
    public static void isReverse(String s1){
    String s2="";
    for(int i=s1.length()-1;i>=0;i--){
        s2=s2+s1.charAt(i);
        if(s1.equals(s2)){
            System.out.println(s2);
        }
    }
    }
}