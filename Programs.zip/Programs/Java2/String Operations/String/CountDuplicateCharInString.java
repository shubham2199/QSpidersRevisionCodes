import java.util.Scanner;

class CountDuplicateCharInString{
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the String");
        String s1=s.nextLine();
        int count=0;
        char[] s2=s1.toCharArray();
        for(int i=0;i<=s1.length()-1;i++){
            count=1;
            for(int j=i+1;j<=s1.length()-1;j++){
                if(s2[i]==s2[j]&&s2[i]!=' '){
                    count++;
                    s2[j]=' ';
                } 
            }if(count>1)
                System.out.println(s2[i]);
        }
        s.close();       
    }
}