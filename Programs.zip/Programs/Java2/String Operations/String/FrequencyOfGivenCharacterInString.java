import java.util.Scanner;

public class FrequencyOfGivenCharacterInString {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the String");
        String s1=s.nextLine();
        s1=s1.toLowerCase();
        System.out.println("Enter the Character to be find");
        char ch=s.next().charAt(0);
        int count=0;
        for(int i=0;i<=s1.length()-1;i++){
            if(ch==s1.charAt(i))
            count++;
        }
        System.out.println(count);
        s.close();
    }
}
