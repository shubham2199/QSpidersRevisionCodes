import java.util.Scanner;

public class CountAllCaractersInString {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the String");
        String s1=s.nextLine();
        s1=s1.toLowerCase();
        char[] ch=s1.toCharArray();
        int[] count=new int[s1.length()];
        for(int i=0;i<=s1.length()-1;i++){
            count[i]=1;
            for(int j=i+1;j<=s1.length()-1;j++){
                if(ch[i]==ch[j]){
                    count[i]++;
                    ch[j]=' ';
                }
            }
        }
        for(int i=0;i<=count.length;i++){
            if(ch[i]!=' ')
            System.out.println(ch[i]+"="+count[i]);
        }
    }
}
