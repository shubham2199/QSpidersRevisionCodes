import java.util.*;
public class ReverseString {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.print("Enter the String value : ");
        String s1=s.nextLine();
        String s2="";
        int l=s1.length();
        for(int i=l-1;i>=0;i--){
            s2=s2+s1.charAt(i);
        }
        System.out.println(s2);
    }
}
