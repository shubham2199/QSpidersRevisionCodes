package Map;

import java.util.*;

public class MapDeo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Map m = new Hashtable();
		
		m.put(1,"hello");
		m.put(2,25);
		m.put(4,"hii");
		m.put(3,63);
		
		
		System.out.println(m);
		
		Map m1 = new LinkedHashMap();
		Map m2 = new LinkedHashMap();
		
		m1.put(25,45);
		m1.put(21,5);
		m2.put(5,"hello");
		m2.put(10,"thamks");
		
		m1.putAll(m2);
		System.out.println(m1);
		
		m.remove(4);
		System.out.println(m);
		
		Map m4 = new TreeMap();
		m4.putAll(m2);
		m4.putAll(m1);
		m4.putAll(m);
		System.out.println(m4);
	}

}
