package Map;
import java.util.*;

public class StringCount {
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Enter String.");
		String st= sc.nextLine();
		int size = st.length();
		System.out.println(size);
		String []st1 = new String[size];
		int count=0;
		for(int i=0;i<st1.length;i++) {
		
			if(st1[i].equals(st1[i]+1)) {
				count++;
				if(count !=1) {
					System.out.println(st1[i]);
				}
			}else {
				count=0;
			}
			
		}
	}

}
