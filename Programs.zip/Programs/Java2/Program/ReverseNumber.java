import java.util.*;
class ReverseNumber{

	public static void main(String[] args){

		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the number: ");
		long num = sc.nextLong();
			
		long rev=0, temp=num;
		for(;num>0;num/=10){
		
			long rem = num%10;
			rev =(rev*10) + rem;
		}
		System.out.println(temp);
		System.out.println(rev+" is the reverse number.");
	} 
}