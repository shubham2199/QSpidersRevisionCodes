import java.util.*;
class ArmStrongNumber{
	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the no: ");
		int num = sc.nextInt();
		int temp=num;
		int temp1=num;
		int length = power(num);
		int sum = extract(temp,length);
		
		if(sum == temp1){
		
			System.out.println(temp+" is an Amstrong Number");
		}else{
			System.out.println(temp+"is not an Amstrong Number");
		}
	}
	
	public static int power(int num){
	
		int power=0;
		while(num>0){
			
			num = num/10;
			power++;
		}
		return power;
	}
		
	public static int extract(int temp,int length){

		int sum=0;
		while(temp>0){
			int rem = temp%10;
			sum = sum + product(rem,length);
			temp= temp/10;
		}
		return sum;
	}

	public static int product(int rem, int length){

		int product=1;
		while(length>0){
				
			product = product * rem;
			length--;
		}
		return product;
	}
	
}