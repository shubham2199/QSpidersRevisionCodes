class Add{
	
	public static int add(int no1, int no2){
	
		return no1+no2;
	}
	
	public static void main(String[] args){

		System.out.println(add(20,30));
	}

}