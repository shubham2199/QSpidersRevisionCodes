class TypeCast1{
	public static void main(String[] args){
		
		char c1='a',c2='z';
		
		System.out.println("Alphabet"+"\t"+"Ascii Value");
		do{
				
			int n1= (int)c1;
			System.out.println("   "+c1+"\t:->\t "+n1);
			c1++;
		}while(c1<=c2);
	}
}