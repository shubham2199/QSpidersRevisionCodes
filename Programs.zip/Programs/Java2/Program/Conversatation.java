class Conversatation {

	public static void main(String [] args){
		
		majanu();
	} 
	
	public static void majanu(){
	
		System.out.println(" :-) Hii laila");
		laila();
		System.out.println(" :-) Nahi aaj mere dostlog ane wale he......");
		System.out.println(" :-) Bhad me ja tu ........");
		System.out.println(" :-) mere dost party karane wale tu chakana lakar de.......");
	}
	
	public static void laila(){
		
		System.out.println(" :-> Hey Majanu....");
		System.out.println(" :-> Chalo Kahi ghumane chalate he....");
		
	}
}