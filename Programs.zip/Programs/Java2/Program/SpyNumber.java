import java.util.*;
class SpyNumber{

	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the number: ");
		int num = sc.nextInt();
		int temp=num;
		int sum = 0, product=1;

		for(;num>0;num/=10){
			
			int rem = num%10;
			sum = sum +rem;
			product = product * rem;
		}
		if(sum == product){
	
			System.out.println(temp+" is an SPY Number.");
		}else{
		
			System.out.println(temp+" is not an SPY Number.");
		}
	}
}