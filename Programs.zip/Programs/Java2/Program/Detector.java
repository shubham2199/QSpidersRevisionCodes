class Detector{

	public static void main(String [] args){
		
		Lucifer();		
	}
	public static void Lucifer(){
		
		System.out.println("---------------------------------------------");
		System.out.println("My location is "+Cloei("Devil"));
		System.out.print("---------------------------------------------");
		return;
	}

	public static String Cloei(String name){
	
		System.out.println("My name is "+name);
		return "Heven";
	}
}