import java.util.*;
class SunnyNumber{

	public static void main(String[] args){
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the no: ");
		int no1=sc.nextInt();
		int add = no1+1;
		double square = Math.sqrt(add);
		double no2 = square * square;    // type cast is also work here
		if(no2 == add){
			System.out.println(no1+" is an sunny No.");
		}
	}
}