class MyAdd{
	public static void main(String [] args){
		
		System.out.println("----------------------------------------------------");
		System.out.print("   Shubham Balasaheb Sodnawar. \n");
		System.out.println(" My Address Is:- Uday Home, Boripardhi, Kedgaon, Daund, Pune. ");
		System.out.println("----------------------------------------------------");
	}
}