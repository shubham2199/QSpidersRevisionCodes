class EvenTypeCast1{
	public static void main(String[] args){
		
		int n1=65;
		
		System.out.println("Alphabet"+"\t"+"Ascii Value");
		do{
			if(n1%2==0){
				char c1= (char)n1;
				System.out.println("   "+n1+"\t:->\t "+c1);
			}
			n1++;
		}while(n1<=90);
	}
}