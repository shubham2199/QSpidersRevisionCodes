package com.program;

public class FinalClass {
	
	public FinalClass(){
	System.out.println("Its Final Class");
	}
}

final class Andriod extends FinalClass{

	public Andriod() {
		System.out.println("Its Andriod Class");
	}

	public static void main(String[] args) {
		new FinalClass();
		
	}
}


