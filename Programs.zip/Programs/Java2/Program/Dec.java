class Dec{

	public static void main(String[] args){
	
		int a=10;
		--a;
		System.out.println(a);
	}
}