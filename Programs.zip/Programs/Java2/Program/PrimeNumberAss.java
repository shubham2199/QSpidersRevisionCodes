import java.util.Scanner;
class PrimeNumberAss{
	
 	public static void main(String arg[]){
 		
		Scanner sc = new Scanner(System.in);
		System.out.print("Users selection: ");
		int num = sc.nextInt();
	
		primeCount(num);
	}
 		
     		
 	public static int primeCount(int num){
		
		int i,count,count1=0,j=0;
		System.out.println();
		System.out.println("User Selection\tResult");
 
		for(j=2;j<=100;j++){
 			count=0;
			 for(i=1;i<=j;i++){

				if(j%i==0){
         				count++;        
    				}
 			}
 			if(count==2){
				count1++;
				if(count1 == num){
        				System.out.println("   "+count1+"\t\t "+j);
				}     
 			}
		}
		return 0;
 	}
	
}