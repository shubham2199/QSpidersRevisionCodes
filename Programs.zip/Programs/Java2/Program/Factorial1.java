import java.util.*;
class Factorial1{

	public static void main(String[] args){

		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the no: ");
		int no1=sc.nextInt();
		int temp=no1;
		int sum=0;
		while(no1>0){
			
			int rem = no1%10;
			sum = sum + fact(rem);
			no1 = no1/10;
		}
		if(temp == sum)
			System.out.println("It is a Strong Number.");
		else
			System.out.println("It is not a Strong Number.");
	}
	
	public static int fact(int rem){
		int fact1=1;
		for(int i=rem;i>0;i--){

			fact1 = fact1*i;
		}
		return fact1;
	}
}


