class W2{

	public static void main(String[] args){
	
		char n = 'a';
		int i = n;
		float f = n;
		long l = n;
		double d = n;
		System.out.println(n);
		System.out.println(i);
		System.out.println(f);
		System.out.println(l);
		System.out.println(d);
	}
}