class DataTypeConverter{

	public static void main(String[] args){
		
		byte b1 = 10, b2 = 30 ;
	//	short b1 = 10, b2 = 30 ;
	//	int b1 = 10, b2 = 30 ;
	//	char b1 = 'a', b2 = 'c' ;
	//	long b1 = 1069l, b2 = 3025l ;
	//	float b1 = 10.23f, b2 = 30.65f ;
	//	double b1 = 10254d, b2 = 30458d ;
	//	boolean b1 = true, b2 = false ;
	//	String b1 = "yes",b2 = "no" ;

	
	//	byte b3 = b1-b2;
	//	short b3 = b1-b2;
	//	int b3 = b1-b2;
	//	char b3 = b1-b2;
	//	long b3 = b1-b2;
	//	float b3 = b1-b2;
	//	double b3 = b1-b2;
	//	boolean b3 = b1-b2;
	//	String b3 = b1-b2;

	//	System.out.println(b3);
	}
}