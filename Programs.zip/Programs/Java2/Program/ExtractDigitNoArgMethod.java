import java.util.*;
class ExtractDigitNoArgMethod{

	public static void main(String[] args){
		
		NoargMethod();
	}
	
	public static void NoargMethod(){
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter No here: ");
		long l1 = sc.nextLong();

		for(;l1>0;l1/=10){
			
			long res=l1%10;
			System.out.println(res);
		}
	}
}