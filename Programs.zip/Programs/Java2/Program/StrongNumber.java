import java.util.*;
class StrongNumber{

	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the number: ");
		int num = sc.nextInt();
		int temp=num,sum=0;

		for(;num>0;num/=10){

			int rem = num%10;
			sum = sum +factOfNumber(rem);
		}
		if(temp == sum){

			System.out.println(temp+" is an Strong Number.");
		}else{

			System.out.println(temp+" is not an Strong Number.");
		}
	}

	public static int factOfNumber(int rem){
		
		int fact=1;
		for(int i=rem;i>0;i--){

			fact = fact * i;
		}
		return fact;
	}
}