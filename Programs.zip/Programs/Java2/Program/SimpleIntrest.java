class SimpleIntrest{

	public static void main(String[] args){

		
		int p = 10000, t = 2;
		float ri = 0.12f;
		float si,ta;

		si = (p*ri*t)/100;
		ta = si + p;
		System.out.println(" Simple Intrest Is : "+ si);
		System.out.println(" The Principal Is : "+ p);
		System.out.println(" The Total Amount Is : "+ ta);
		
	}
}