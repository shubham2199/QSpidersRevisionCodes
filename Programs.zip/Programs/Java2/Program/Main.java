class Rectangle{

	public static double AreaOfRectangle(double w, double l){
	
		return w*l;
	}
}

class Main{

	public static void main(String[] args){
	
		System.out.println(Rectangle.AreaOfRectangle(5.6,4.2));
	}
}