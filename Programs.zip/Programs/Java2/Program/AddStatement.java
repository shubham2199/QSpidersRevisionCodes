import java.util.*;

class AddStatement{

	public static void main(String[] args){

		Scanner sc = new Scanner(System.in);
		int no1,no2;
		System.out.println("Enter the two no: ");
		no1 = sc.nextInt();
		no2 = sc.nextInt();

		int sum = no1 + no2;
		
		if(sum == 5){
		
			System.out.println("Yes the sum is equal to five.");
		}
		
		System.out.println("*******************************");
	}
} 