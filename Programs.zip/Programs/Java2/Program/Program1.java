import java.util.*;

public class Program1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        // int n = sc.nextInt();
        // int dis = sc.nextInt();
        // int c = 0, i = 0;
        // int order[] = new int[n];
        // for (; i < n; i++) {
        // order[i] = sc.nextInt();
        // if (order[i] > 0 && dis % order[i] == 0) {
        // c++;
        // }
        // }

        System.out.println('b' + 'i' + 't');
    }
}
