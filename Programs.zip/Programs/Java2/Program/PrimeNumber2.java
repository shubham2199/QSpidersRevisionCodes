import java.util.*;
class PrimeNumber2{

	public static void main(String[] args){

		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the no: ");
		int num = sc.nextInt();
		
		if(num==0 || num==1){

			System.out.println("Is Not an Prime Number.");
		}else{

			int i;
			for(i=2;i<num;i++){

				if(num%i==0){

					System.out.println(num+" Is not an Prime Number.");
					break;
				}
			}
			if(i==num){

				System.out.println(num+" Is an Prime Number.");
			}
		}
	
	}
}
