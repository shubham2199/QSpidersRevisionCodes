import java.util.*;
class UpperToLowerCase{

	public static void main(String[] args){
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter Character/Alphabet : ");
		char ch1 = sc.next().charAt(0);

		if(ch1>='a' && ch1<='z'){

			int no = (int)ch1-32;
			System.out.println((char)no);
		}else if(ch1>='A' && ch1<='Z'){

			int no = (int)ch1+32;
			System.out.println((char)no);
		}
	}
}