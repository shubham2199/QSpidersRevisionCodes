import java.util.*;
class ExtractDigitParaArgu{

	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter No here: ");
		long l1 = sc.nextLong();
		ParameterisedMethod(l1);
	}
	
	public static void ParameterisedMethod(long l2){

		for( ;l2>0;l2/=10){
			
			long res=l2%10;
			System.out.println(res);
		}
	}
}