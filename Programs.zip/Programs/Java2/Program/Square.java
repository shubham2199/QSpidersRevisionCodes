class Square{
	
	public static int square(int no1){
	
		return no1*no1;
	}
	
	public static void main(String[] args){

		System.out.println(square(12));
	}

}