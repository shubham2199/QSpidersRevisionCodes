import java.util.*;
class ExtractDigitalSum{

	public static void main(String[] args){
	
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter no here: ");
		int no1 = sc.nextInt();
			
		int sum= digitalSum(no1);
		System.out.println("The Digital Sum is : "+sum);
	}
	
	public static int digitalSum(int no1){
		
		int sum=0;
		for(;no1>0;no1/=10){
			
			int rem =no1%10;
			sum+=rem;
		}

		return sum;
	}
}