import java.util.Scanner;
class DreamCompany{
	
	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter Your Dream Company : ");
		String st1 = sc.next();
		String st2 = sc.next();
		String st3 = sc.next();
		String st4 = sc.next();
		String st5 = sc.next();

		System.out.println("-----------------*****-----------------");
		System.out.println("1."+st1);
		System.out.println("2."+st2);
		System.out.println("3."+st3);
		System.out.println("4."+st4);
		System.out.println("5."+st5);
		System.out.println("-----------------*****-----------------");
	}

}