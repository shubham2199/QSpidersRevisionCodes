import java.util.Scanner;
class AddTypeCast{
	
	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		double no1,no2;

		System.out.println("Enter the first and second no: ");
		no1 = sc.nextDouble();
		System.out.println("First no is: "+no1);
		no2 = sc.nextDouble();
		System.out.println("Second no is: "+no2);

		double sum = no1+no2 ;
		System.out.println("Sum is: "+(int)sum);
	}

}