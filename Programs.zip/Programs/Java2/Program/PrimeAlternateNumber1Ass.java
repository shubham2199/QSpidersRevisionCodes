import java.util.Scanner;
class PrimeAlternateNumber1Ass{
	
 	public static void main(String arg[]){
 		
		Scanner sc = new Scanner(System.in);
		System.out.print("Start from : ");
		int start = sc.nextInt();
		
		primeAlternateNumber(start);
	}
 		
     		
 	public static int primeAlternateNumber(int start){
		
		int i,count,count1=0,j=0;
		System.out.println();
		System.out.println("Result");
 
		for(j=start;j<=100;j++){
 			count=0;
			 for(i=1;i<=j;i++){

				if(j%i==0){
         				count++;        
    				}
 			}
 			if(count==2){
				count1++;
				if(count1 % 2 !=0){
        				System.out.println(j);
				}     
 			}
		}
		return 0;
 	}
	
}