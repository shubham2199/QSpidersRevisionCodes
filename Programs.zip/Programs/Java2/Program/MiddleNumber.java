import java.util.*;

class MiddleNumber{

	public static void main(String [] args){

		Scanner sc = new Scanner(System.in);

		System.out.print("Enter First No: ");
		int i1 = sc.nextInt();

		System.out.print("Enter Second No: ");
		int i2 = sc.nextInt();

		System.out.print("Enter Third No: ");
		int i3 = sc.nextInt();

		if((i2>i1 && i2<i3) || (i2<i1 && i2>i3)) {
			
			System.out.println(i2+" is middle no.");
		}

	}
}