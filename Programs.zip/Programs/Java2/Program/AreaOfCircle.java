class AreaOfCircle{

	public static void main(String[] args){
	
		int r = 2;
		float pi = 3.14f;
		float area;
	
		area = pi*r*r;
	
		System.out.println("Area of Circle is: "+ area);
	}
}