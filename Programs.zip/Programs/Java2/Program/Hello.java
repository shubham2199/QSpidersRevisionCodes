class Hello {

	public int isLeapYear(int year){
		if(year == 0){
			System.out.println(true);
		}else{
			System.out.println(false);
		}
		return year;
	}
	public static void main (String [] args){
		
		Hello h = new Hello();

		System.out.println(h.isLeapYear(2000)); // true
		System.out.println(h.isLeapYear(1900)); // false
		System.out.println(h.isLeapYear(2022)); // true
	}
}