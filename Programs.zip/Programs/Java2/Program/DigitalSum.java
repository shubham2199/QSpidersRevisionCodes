import java.util.*;
class DigitalSum{

	public static void main(String[] args){
	
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no here: ");
		int no1 = sc.nextInt();
		int sum=0;
		
		for(; no1>0;no1/=10){
		
			int rem=no1%10;
			sum+=rem;
		}
		System.out.println("The Digital Sum is : "+sum);
	}
}