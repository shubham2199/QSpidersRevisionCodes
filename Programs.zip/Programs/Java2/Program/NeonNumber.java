import java.util.*;
class NeonNumber{

	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the number: ");
		int num = sc.nextInt();
		int num1 = num * num;
		int sum =0;

		for(;num1>0;num1/=10){

			int rem = num1%10;
			sum = sum + rem; 
		}
		if(sum == num){
			System.out.println(num+" is an Neon Number.");
		}else{
			System.out.println(num+" is not an Neon Number.");
		}
	}
}