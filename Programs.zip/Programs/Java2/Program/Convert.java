class Convert{

	public static void main(String [] args) {
		
		int b = 44;
	//	byte s = b;
	//	short i = b;
		long l = b;
		float f = b;
		double d = b;
		//char ch = b;
		//boolean bo = b;
	
		System.out.println(" "+b+" "+" "+l+" "+f+" "+d);
	}
}