import java.util.*;
class ReverseNumber1{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number: ");
		int number = sc.nextInt();
		while(number>0){
		int rem = number%10;
		System.out.print(rem);
		number /= 10;
		}
	}
}
