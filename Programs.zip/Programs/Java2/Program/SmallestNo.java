import java.util.*;

class SmallestNo{

	public static void main(String[] args){

		Scanner sc = new Scanner(System.in);
		int no1,no2;
		System.out.println("Enter the two no: ");
		no1 = sc.nextInt();
		no2 = sc.nextInt();
		
		if(no1<no2){
		
			System.out.println(no1+" is the smaller than "+no2);
		}else{
			System.out.println(no2+" is the smaller than "+no1);	
		}
		
	}
} 