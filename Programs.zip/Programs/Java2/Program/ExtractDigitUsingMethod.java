import java.util.*;
class ExtractDigitUsingMethod{

	public static void main(String[] args){
		Digit();
	}
	public static void Digit(){
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the No: ");
		int no1 = sc.nextInt();

		for(;no1>0;no1/=10){
		
			int res=no1%10;
			System.out.println(res);
		}
	}
}