import java.util.*;
class ExtractedDigitEvenOdd{

	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the No: ");
		long no1 = sc.nextLong();

		for(;no1>0;no1/=10){
		
			long res=no1%10;
			if(res%2==0){
				System.out.println(res+" is Even Number.");
			}else{
				System.out.println(res+" is Odd Number.");
			}
		}
	}
}