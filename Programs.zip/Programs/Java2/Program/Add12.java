import java.util.Scanner;
class Add12{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter The range from user : ");
		int r1=sc.nextInt();
		int r2=sc.nextInt();

		int sum=0;
		int i=r1;
		while(i<=r2){
			
			sum = sum + r1;
			r1++;
			i++;
		}
		System.out.println(sum);
	}
}