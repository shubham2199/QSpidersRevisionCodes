import java.util.*;
class NthPrimeNumber{

	public static void main(String[] args){

		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the Position: "); 
		int pos = sc.nextInt();
		int i=1,count=0;

		for(;i<=pos;i++){

			if(isPrime(i)){

				count++;
			}
		}
		System.out.println("Is the Position"+i+" and this is the number "+pos);
	}

	public static boolean isPrime(int num){

		if(num == 0 || num==1)
			return false;
	
		else{

			int i;
			for(i=2;i<num;i++){

				if(num%i==0)
					return false;
			}
		}
		return true;
	}
}