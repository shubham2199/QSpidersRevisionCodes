import java.util.Scanner;
class Add11{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter the range starting from : ");
		int r1=sc.nextInt();

		int sum=0;
		int i=r1;
		int r3=r1+10;
		while(i<=r3){
			
			sum = sum + r1;
			r1++;
			i++;
		}
		System.out.println(sum);
	}
}