class MyInfo{

	public static void MyDetails(){
		
		System.out.println("Shubham Sodnawar.");
		System.out.println("BE (Comp).");
		System.out.println("2021 Pass Out.");
		System.out.println("--------------------------------");	
	}
	
	public static void main(String [] args){
		
		MyInfo s = new MyInfo();
		
		for(int i=0;i<2;i++){
		
			s.MyDetails();
			
		}
	}
}