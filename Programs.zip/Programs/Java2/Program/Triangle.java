class Triangle{

	public static void AreaTriangle(float opside, float adjacent){
	
		float hypotenious;
		System.out.println("--------------------------------------");
		hypotenious = (opside * adjacent )/2;
		System.out.println("Area of Triangle is "+hypotenious);
		System.out.println("--------------------------------------");
	}
	
	public static void main(String [] args){
		
		float op = 4;
		float adj = 5;
		
		AreaTriangle(op,adj);
	}
}