import java.util.*;

class DivideStatement{

	public static void main(String[] args){

		Scanner sc = new Scanner(System.in);
		int no1,no2;
		System.out.println("Enter the two no: ");
		no1 = sc.nextInt();
		no2 = sc.nextInt();
		
		if(no1%no2 == 0){
		
			System.out.println("No1 is: "+no1);
			System.out.println("No2 is: "+no2);
		}
		
		System.out.println("*******************************");
	}
} 