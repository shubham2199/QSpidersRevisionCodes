class Long{

public static void main(String[] args) {

	long l = 7304302199l;
	System.out.println(l);
}
}