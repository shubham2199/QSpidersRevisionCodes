import java.util.*;
class SmallestFourNumber{

	public static void main(String [] args){

		Scanner sc = new Scanner(System.in);

		System.out.print("Enter First No: ");
		int i1 = sc.nextInt();

		System.out.print("Enter Second No: ");
		int i2 = sc.nextInt();

		System.out.print("Enter Third No: ");
		int i3 = sc.nextInt();

		System.out.print("Enter Fourth No: ");
		int i4 = sc.nextInt();
		
		if(i1<i2 && i1<i3 && i1<i4) {
			
			System.out.println(i1+" is less no.");
		}else if( i2<i3 && i2<i4){
			
			System.out.println(i2+" is less no.");
		}else if(i3<i4){
		
			System.out.println(i3+" is less no.");
		}else{
			
			System.out.println(i4+" is less no.");
		}

	}
}