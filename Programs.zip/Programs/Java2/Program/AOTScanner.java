import java.util.Scanner;
class AOTScanner{
	
	public static void main(String[] args){
		
		Scanner sc = new Scanner(System.in);
		double height,width;

		System.out.println("Enter the Hight and Width of triangle: ");
		height = sc.nextDouble();
		System.out.println("Height Of triangle is: "+height);
		width = sc.nextDouble();
		System.out.println("Width Of triangle is: "+width);

		double aof = (height * width)/2;
		System.out.println("Area Of triangle is: "+aof);
	}

}