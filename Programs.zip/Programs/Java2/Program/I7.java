class I7{

	public static void main(String[] args){
		
		int a =20;
		int b=15;
		String str = a>b? "true":"13.5";
	}
}