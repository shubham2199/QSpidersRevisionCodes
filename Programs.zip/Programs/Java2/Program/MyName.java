class MyName{
	public static void main(String [] args){
		
		System.out.println("----------------------------------------------------");
		System.out.println("   Shubham Balasaheb Sodnawar. ");
		System.out.println(" My Year Of Pass out is :- 2021.");
		System.out.println("My Branch Is :- Computer Engineering.");
		System.out.println("----------------------------------------------------");
	}
}