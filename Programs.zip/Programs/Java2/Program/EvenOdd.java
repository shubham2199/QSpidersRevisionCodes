import java.util.*;

class EvenOdd{

	public static void main(String[] args){

		Scanner sc = new Scanner(System.in);
		int no1;
		System.out.println("Enter the no: ");
		no1 = sc.nextInt();
		
		if(no1 % 2 ==0){
		
			System.out.println(no1+" is Even No.");
		}else{
			System.out.println(no1+" is Odd No.");	
		}
		
	}
} 