import java.util.*;
	class GretestNumber{
		public static void main(String[] args){
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter three numbers: ");
			int number1 = sc.nextInt();
			int number2 = sc.nextInt();
			int number3 = sc.nextInt();
			if(number1>number2 || number1> number3){
				System.out.println(number1+" is greater than another two numbers.");
			}else if(number2> number3 ){
				System.out.println(number2+" is greater than another two numbers.");
			}else{
				System.out.println(number3+" is greater than another two numbers.");
			}
		}
	}
