class Pattern{

	public static void main(String[] args){
		
		String s = "|";
		for(int i=0;i<=3;i++){
			for(int j=0;j<=3;j++){
				if(j-i<1){
					System.out.print(s);
				}else{
					System.out.print(" ");	
				}
			}
				System.out.println();

		}
	}
}