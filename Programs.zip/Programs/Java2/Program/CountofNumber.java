import java.util.Scanner;
class CountofNumber{
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter any no: ");
		long l1= sc.nextLong();
		int count=0;
		
		for(;l1>0;l1/=10){
			
			long num=l1%10;				
			count++;
		}
		System.out.println(count);
	}
}