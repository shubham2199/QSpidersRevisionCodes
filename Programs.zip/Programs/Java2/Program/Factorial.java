import java.util.*;
class Factorial{

	public static void main(String[] args){

		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the no: ");
		int no1=sc.nextInt();
		int sum=0;
		for(;no1>0;no1/=10){
			int fact=1;
			int rem = no1%10;
			while(rem>0){
				
				fact = fact * rem;	 
				rem--;
			}
			sum = sum + fact;
		}
		System.out.println(sum+" is the sum of Factorial Number.");
	}
}


/*
import java.util.*;
class Factorial1{

	public static void main(String[] args){

		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the no: ");
		int no1=sc.nextInt();
		int sum=0;
		while(no1>0){
			
			int rem = no1%10;
			sum = sum + fact(rem);
			no1 = no1/10;
		}
		System.out.println(sum+" is the sum of Factorial Number.");
	}
	
	public static int fact(int rem){
		int fact1=1;
		for(int i=rem;i>0;i--){

			fact1 = fact1*i;
		}
		return fact1;
	}
}
*/