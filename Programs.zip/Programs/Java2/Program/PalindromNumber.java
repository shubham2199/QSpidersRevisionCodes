import java.util.*;
class PalindromNumber{

	public static void main(String[] args){

		Scanner sc=new Scanner(System.in);
		System.out.print("Enter the Number: ");
		int num = sc.nextInt();
		int sum=0,temp=num;

		while(num>0){
		
			int rem = num%10;
			sum = (sum*10) + rem;
			num = num/10;
		}		
		if(temp == sum){
			System.out.println(temp+ " is a palindrom number.");
		}else{
			System.out.println(temp+ " is not an palindrom number.");
		}
	}
}