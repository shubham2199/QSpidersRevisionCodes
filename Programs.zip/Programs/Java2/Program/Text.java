class Text{
	public static void main(String [] args){
		
		int i=1;
		do{
			System.out.println(i+"."+"Before giving the mock we will prepare and take STAR(*).");
			i++;
		}while(i<=10);
	}
}