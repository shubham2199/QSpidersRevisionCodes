class Dreams{

	public static void MyDreams(){

		System.out.println("------------------------------");
		System.out.println(" Dream Location Maldivs. ");
		System.out.println(" Dream Car Rolls Royce. ");
		System.out.println(" The Biggest FarmHose. ");
		System.out.println(" Dream Company Google. ");
		System.out.println("------------------------------");
	}
		
	public static void main(String[] args) {

		MyDreams();
	}
}