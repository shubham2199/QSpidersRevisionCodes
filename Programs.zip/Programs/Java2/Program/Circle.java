class Circle{

	public static void AreaCircle(float r1,float pi1){
		System.out.println("-----------------------------------");
		float res = 2*r1*pi1;
		System.out.println("Area of Circle is "+res);
		System.out.print("-----------------------------------");
	}
	public static void main(String[] args){
	
		float pi = 3.14f;
		int r = 5;
		AreaCircle(r,pi);
	}
}