package com.manytomany;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class StudentDriver {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("jayesh");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		
		Student s=new Student();
		s.setId(1);
		s.setName("CaptainA");
		
		Student s2=new Student();
		s2.setId(2);
		s2.setName("IronMan");
		
		Course c1=new Course();
		c1.setId(1);
		c1.setCname("sql");
		c1.setFees(2000);
		
		
		Course c2=new Course();
		c2.setId(2);
		c2.setCname("devops");
		c2.setFees(3000);
		
		List<Course>courses=new ArrayList<Course>();
		courses.add(c1);
		courses.add(c2);
		
		s.setCourses(courses);
		s2.setCourses(courses);
		
		
		et.begin();
		em.merge(s);
		em.merge(s2);
		em.merge(c1);
		em.merge(c2);
		et.commit();
		
		
		
	}

}
