package com.manytoone;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class CountryDriver {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Gan");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		
		Country c=new Country();
		c.setId(1);
		c.setName("India");
		c.setPopulation(200000);
		
		Country c1=new Country();
		c1.setId(2);
		c1.setName("America");
		c1.setPopulation(150000);
		
		State s=new State();
		s.setId(1);
		s.setName("MH");
		s.setC(c);
		
		State s1=new State();
		s1.setId(2);
		s1.setName("GJ");
		s1.setC(c);
		
		State s2=new State();
		s2.setId(3);
		s2.setName("California");
		s2.setC(c1);
		
		State s3=new State();
		s3.setId(4);
		s3.setName("Texas");
		s3.setC(c1);
		
		et.begin();
		em.persist(s);
		em.persist(s1);
		em.persist(s2);
		em.persist(s3);
		em.persist(c);
		em.persist(c1);
		
		et.commit();

	}

}
