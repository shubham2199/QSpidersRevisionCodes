package com.manytoone;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class AccDriver {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Gan");
		EntityManager em=emf.createEntityManager();
		EntityTransaction et=em.getTransaction();
		
		Account account=new Account();
		account.setAccno(123);
		account.setAccholdername("Thor");
		
		Transition transition=new Transition();
		transition.setId(1);
		transition.setExpence("Pub");
		transition.setAmount(2000);
		transition.setA(account);
		
		et.begin();
		em.persist(account);
		em.persist(transition);
		et.commit();
	}

}
