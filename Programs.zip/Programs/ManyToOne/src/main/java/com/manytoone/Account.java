package com.manytoone;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Account {
	@Id
	private int accno;
	private String accholdername;
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public String getAccholdername() {
		return accholdername;
	}
	public void setAccholdername(String accholdername) {
		this.accholdername = accholdername;
	}
	
}
