package com.manytoone;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class FetchData {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Gan");
		EntityManager em=emf.createEntityManager();
		
		State s=em.find(State.class, 3);
		System.out.println(s.getId());
		System.out.println(s.getName());
		
		Country c=s.getC();
		System.out.println(c.getId());
		System.out.println(c.getName());
		System.out.println(c.getPopulation());
	}

}
