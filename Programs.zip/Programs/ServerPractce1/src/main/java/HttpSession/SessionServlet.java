package HttpSession;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/httpsession")
public class SessionServlet extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
	
		String email = req.getParameter("email");
		String pass = req.getParameter("pass");
		
		HttpSession hs = req.getSession();
		hs.setAttribute("Email",email);
		hs.setAttribute("Pass", pass);
		
		String email1 = (String)hs.getAttribute("Email");
		String pass1 = (String)hs.getAttribute("Pass");
		
	//	Object o = hs.getAttribute("Email");
		
		System.out.println("After Inserting");
		System.out.println(email1);
		System.out.println(pass1);
		
		// December 12,2022
		
		hs.removeAttribute("Pass");
		String pass2 = (String) hs.getAttribute("Pass");
		System.out.println("After Removing");
		System.out.println(pass2);
		
		//remove attribute is use to delete / remove a particular data.
		// invalidate can destroy the whole data.
		
		//hs.invalidate();
		
		//Fetch the data by using another object
		HttpSession h1 = req.getSession();
		String email2 = (String) h1.getAttribute("Email");
		System.out.println("Calling From Another Object");
		System.out.println(email2);
	}
}
