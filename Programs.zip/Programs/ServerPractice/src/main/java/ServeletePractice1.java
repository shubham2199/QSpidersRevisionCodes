import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/Form")
public class ServeletePractice1 extends GenericServlet{
	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		
		String passWord = req.getParameter("pass");
		String eMail = req.getParameter("Email");
		
		if(eMail.equals("kingsmen.2199@gmail.com") && passWord.equals("Ganesh@2199")) {
		RequestDispatcher rd = req.getRequestDispatcher("/log");
		rd.forward(req, res);
		}else {
			PrintWriter pw = res.getWriter();
			pw.write("Invalid Credentials");
			RequestDispatcher rd = req.getRequestDispatcher("FormServlet.html");
			rd.include(req, res);
			res.setContentType("text/html");
		}
	}
}
