package doPostMethod;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/servlet2")
public class Servlet2 extends HttpServlet{

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String FName = req.getParameter("FName");
		String LName = req.getParameter("LName");
		String Age = req.getParameter("Age");
		String PassWord = req.getParameter("password");
		
		System.out.println(FName);
		System.out.println(LName);
		System.out.println(Age);
		System.out.println(PassWord);
	}
}
