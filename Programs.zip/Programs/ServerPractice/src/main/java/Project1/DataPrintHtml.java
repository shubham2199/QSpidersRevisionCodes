package Project1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;

@WebServlet("/Form1")
public class DataPrintHtml extends GenericServlet {
	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	
		String PassWord = req.getParameter("PassWord");
		String Email = req.getParameter("Email");
		
		if(Email.equals("kingsmen.2199@gmail.com") && PassWord.equals("Ganesh@2199")) {
		RequestDispatcher rd = req.getRequestDispatcher("DPHFile2.html");
		rd.forward(req, res);
		}else {
			PrintWriter pw = res.getWriter();
			pw.write("Invalid Credentials");
			RequestDispatcher rd = req.getRequestDispatcher("DHPFile1.html");
			rd.include(req, res);
			res.setContentType("text/html");
		}
	}
}
