import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/log")
public class ServeletePractice2 extends GenericServlet{
	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String fName = req.getParameter("FName");
		String lName = req.getParameter("LName");
		String passWord = req.getParameter("pass");
		String eMail = req.getParameter("Email");
		String conNumber = req.getParameter("contact");
		String dateOfBirth = req.getParameter("DOB");
		String gender = req.getParameter("gender");
		
		
			PrintWriter pw = res.getWriter();
			pw.write("Welcome Ganesh");
			pw.write("\nFirst Name:\t"+fName);
			pw.write("\nLast Name:\t"+lName);
			pw.write("\nE-Mail:\t\t"+eMail);
			pw.write("\nContact Number:\t"+conNumber);
			pw.write("\nDate Of Birth:\t"+dateOfBirth);
			pw.write("\nGender:\t\t"+gender);
			
			RequestDispatcher rd = req.getRequestDispatcher("Welcome.html");
			rd.include(req, res);
			res.setContentType("text/html");
			
	}
}
