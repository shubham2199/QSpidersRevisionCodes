import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.GenericServlet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/Ganesh")
public class ProgramFile1 extends GenericServlet {

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("Hello Ganesh");
		String fName = req.getParameter("FName");
		String lName = req.getParameter("LName");
		String passWord = req.getParameter("pass");
		String eMail = req.getParameter("Email");
		String conNumber = req.getParameter("contact");
		String dateOfBirth = req.getParameter("DOB");
		String gender = req.getParameter("gender");
		
//		System.out.println("First Name: "+fName+"\nLastName: "+lName+"\nPassWord: "+passWord+"\nEmail: "+eMail+"\nContact Number: "+conNumber+"\nDate Of Birth: "+dateOfBirth+"\nGender: "+gender);
		
		if(eMail.equals("kingsmen.2199@gmail.com") && passWord.equals("Ganesh@2199")) {
			RequestDispatcher rd = req.getRequestDispatcher("Welcome.html");
			rd.forward(req, res);
		}else {
			PrintWriter pw = res.getWriter();
			pw.write("Invalid Credentials");
			RequestDispatcher rd = req.getRequestDispatcher("Program1.html");
//			rd.forward(req, res);
			rd.include(req, res);
			res.setContentType("text/html");
		}
		
//		PrintWriter pw = res.getWriter();
//		pw.write("Welcome Ganesh");
//		pw.write("First Name:\t"+fName);
//		pw.write("\nLast Name:\t"+lName);
//		pw.write("\nE-Mail:\t\t"+eMail);
//		pw.write("\nContact Number:\t"+conNumber);
//		pw.write("\nDate Of Birth:\t"+dateOfBirth);
//		pw.write("\nGender:\t\t"+gender);
		
	}

}
